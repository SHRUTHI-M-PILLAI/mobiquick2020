const mongoose = require('mongoose');
const Schema= mongoose.Schema;
var RechargeSchema = new Schema({
    rechargePlans :Number,
    rechargeValidity : String,
    rechargeBenifits : String
   
});

 var Recharge = mongoose.model('recharge',RechargeSchema,'recharges');
 module.exports = Recharge;

