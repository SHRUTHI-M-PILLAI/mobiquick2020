const express = require('express')
const cors = require ('cors')
const jwt = require ('jsonwebtoken');
const mongoose = require('mongoose')
const User = require('./models/user')
const Recharges = require('./models/recharges')


const db = "mongodb+srv://mobiquick_123:mobiquick123@cluster0.adjp5.gcp.mongodb.net/AppDb?retryWrites=true&w=majority"

mongoose.connect(db, err => {
    if (err) {


        console.error('Error!' + err)
    } else {
        console.log('Connected to mongodb')
    }
})

var bodyparser = require('body-parser');
const Recharge = require('./models/recharges');
var app = new express();

app.use(cors());
app.use(bodyparser.json());






// function verifyToken(req,res,next){
//     if (!req.headers.authorization){
//          return res.status(401).send('Unauthorized request')
//     }
//     let token = req.headers.authorization.split(' ')[1]
//     if (token === 'null'){
//         return res.status(401).send('Unauthorized request')
//     }
//     let payload = jwt.verify(token,'secretKey')
//     if(!payload){
//         return res.status(401).send('Unauthorized request')
//     }
//     req.userId = payload.subject
//     next()

// }
app.get('/recharge',function(req,res){
    res.header("Access-Control-Allow-Origin","*")
    res.header('Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS')
    Recharges.find()
          .then(function(recharges){
              console.log(recharges)
              res.send(recharges);
          });
});

app.post('/insert',function(req,res){
    res.header("Access-Control-Allow-Origin","*")
    res.header('Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS')
    console.log(req.body);

var recharge ={
    Plans : req.body.recharge.rechargePlans,
   Validity : req.body.recharge.rechargeValidity,
    Benifits : req.body.recharge.rechargeBenifits,

}
var recharge = new (recharge);
recharge.save();
});

app.post('/buy',function(req,res){
    res.header("Access-Control-Allow-Origin","*");
    res.header('Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS');
    console.log(req.body);

    var recharge ={
        Plans : req.body.recharge.rechargePlans,
       Validity : req.body.recharge.rechargeValidity,
        Benifits : req.body.recharge.rechargeBenifits,
    
    }
console.log("Data got in server in edit " +recharge._id);
Recharges.updateOne(
    {_id:req.body.rechargeItem._id},{$set:recharge},
     function(err,res){
     if(err){
         console.log(err)
        }
    }
     )
     
});


app.post('/delete',function(req,res){
    res.header("Access-Control-Allow-Origin","*")
    res.header('Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS')
    console.log(req.body);

    var recharge ={
        Plans : req.body.recharge.Plans,
        Validity : req.body.recharge.rechargeValidity,
        Benifits : req.body.recharge.Benifits
    
    }
    console.log("backend server item is " +recharge._id);
    Recharge.deleteOne(
        {_id:req.body.recharge._id})
        .then(function(recharges){
            res.send(recharges);
        });
        console.log('remove() is executed')
    
    });


    app.post('/register',function(req,res){
        res.header("Access-Control-Allow-Origin","*")
        res.header("Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS")
         let userData= req.body;
         let user = new User(userData);
         user.save((err,registeredUser)=>{
             if(err){console.log(err)}
             else{
                let payload = {subject:user._id}
                let token = jwt.sign(payload,'secretKey') 
                res.status(200).send({token})}
    
         })
    
         
    
    })
    
    app.post('/login',(req,res)=>{
        let userData =req.body;
        User.findOne({email: userData.email},(err,user)=>{
            if(err)
                {
                    console.log(err);
                }
            else{
                if(!user)
                    {
                        res.status(401).send('inavlid email')
                    }
                else if(user.password != userData.password)
                    {
                        res.status(401).send('invalid password')
                    }
                else{
                    let payload = {subject:user._id}
                    let token = jwt.sign(payload,'secretKey') 
                    res.status(200).send({token})
                    
                    }
                }
        })
    
    
    })
    




app.get('/phones',(req,res) => {
    let phones = [
        {
            "_id":"1",
            "name":"Samsung Galaxy M31",
            "color":"Ocean Blue",
            "ram":"6GB",
            "storage":"64 GB",
            "price":"₹ 16,499.00"
        },
        {
            "_id":"2",
            "name":"OPPO Find X2",
            "color":"Ocean",
            "ram":"12GB",
            "storage":"256 GB",
            "price":"₹ 64,990.00",
            "features":"48MP (Sony IMX586 Sensor) wide-angle lens (f/1.7 aperture) rear camera, 12MP (Sony IMX708 Sensor) ultra-wide-angle lens (f/2.2 aperture), 13MP (f/2.4 aperture) telephoto camera | 32MP front facing camera."
        },
        {
            "_id":"3",
            "name":"Samsung Galaxy A21s",
            "color":"Blue",
            "ram":"4 GB",
            "storage":"64 GB",
            "price":"₹ 16,498.00"
        },
        {
            "_id":"4",
            "name":"Oppo Reno3 Pro",
            "color":"Midnight Black",
            "ram":"8GB",
            "storage":"128GB",
            "price":"₹ 29,990.00"
        }
    ]
    res.json(phones)
})



app.listen(5000,function(){
    console.log('listening to port 5000');
});