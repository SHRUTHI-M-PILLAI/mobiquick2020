import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ServicingModel } from './servicing/servicing.model';

@Injectable({
  providedIn: 'root'
})
export class ServicingService {
  private servicing:ServicingModel;
  
  constructor(private http:HttpClient) { }
  getServicing(){
    return this.http.get("http://localhost:5000/servicing");
  }

  setter(servicing){
    console.log("settercalled")

    this.servicing=servicing;
    console.log(servicing);
  }
  hi(){
    return this.servicing;
  }
}