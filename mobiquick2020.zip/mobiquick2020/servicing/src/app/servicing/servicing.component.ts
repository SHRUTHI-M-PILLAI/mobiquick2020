import { Component, OnInit } from '@angular/core';
import {ServicingModel} from './servicing.model';
import {ServicingService} from '../servicing.service';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-servicing',
  templateUrl: './servicing.component.html',
  styleUrls: ['./servicing.component.css']
})
export class ServicingComponent implements OnInit {
  title:String = "Phone Servicing";
  servicing:ServicingModel[];
  imageWidth: number=50;
  imageMargin: number=2;
  showImage: boolean = false;
  constructor(private _servicing:ServicingService, private _router:Router) { }

  toggleImage(): void{
    this.showImage = !this.showImage;
  }
  
  repair(servicing){
    this._servicing.setter(servicing);
     console.log('function called')
     this._router.navigate(['/buy'])
   }

  ngOnInit(): void {
    this._servicing.getServicing()
    .subscribe((data)=>{
      this._servicing=JSON.parse(JSON.stringify(data));
    },
    (err)=>{
      if(err instanceof HttpErrorResponse){
        if(err.status==500){this._router.navigate(['/login'])}
       }
    }
    )
  }
}
 
