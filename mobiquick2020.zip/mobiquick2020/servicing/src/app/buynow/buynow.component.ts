import { Component, OnInit } from '@angular/core';
import { SmartService } from '../smart.service';
import { Router } from '@angular/router';
import { SmartModel } from '../smartphones/smart.model';

@Component({
  selector: 'app-buynow',
  templateUrl: './buynow.component.html',
  styleUrls: ['./buynow.component.css']
})
export class BuynowComponent implements OnInit {
  title:String = "Buy Phone";
  isavailable = false;
  months = ["jan","feb"];
  constructor(private _smart: SmartService, private _router:Router) { }
  productItem = new SmartModel(null,null,null,null,null,null,null,null);

  ngOnInit() {
    
  }
  AddProduct()
  {
    this._smart.newProduct(this.productItem)
    console.log("Called");
    alert("Success");
    this._router.navigate(['/']);
  }

 }

