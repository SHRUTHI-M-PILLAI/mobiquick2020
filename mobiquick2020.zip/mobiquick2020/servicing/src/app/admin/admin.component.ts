import { Component, OnInit } from '@angular/core';
import {RechargesModel} from '../recharges/recharges.model';
import {Router} from '@angular/router';
import { RechargesService } from '../recharges.service';
import {UserService} from '../user.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  title:string = "Admin Area";
  public recharges: RechargesModel[];
  message:string="No active Request";
                 
  enableEdit = false;
  enableEditIndex = null;

  constructor(private rechargesService:RechargesService,private userService:UserService,private router:Router) { }

  ngOnInit(): void {

    this.rechargesService.getRecharges()
      .subscribe((data)=>{
        this.recharges=JSON.parse(JSON.stringify(data));
        console.log('json stringified data' + this.recharges)
      })
  }

}
