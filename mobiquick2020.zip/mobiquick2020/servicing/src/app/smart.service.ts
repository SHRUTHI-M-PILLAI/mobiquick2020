import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SmartModel } from './smartphones/smart.model';

@Injectable({
  providedIn: 'root'
})
export class SmartService {
private smartphone:SmartModel;

  constructor(private http:HttpClient) { }
  getSmartphones(){
    return this.http.get("http://localhost:5000/phones");
  }

  newProduct(item){
    return this.http.post("http://localhost:5000/insert",{"phone":item})
    .subscribe(data=>{console.log(data)})
  }
  setter(smartphone){
    console.log("settercalled")

    this.smartphone=smartphone;
    console.log(smartphone);
  }
  hi(){
    return this.smartphone;
  }
}
