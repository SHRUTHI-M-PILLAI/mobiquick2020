import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
 registerUserData = {email:"",password:""};

  constructor(private _user: UserService,
    private _router:Router) { }

  ngOnInit() {
  }

  registerUser(){
   this._user.registerUser(this.registerUserData)
   .subscribe(
     res=>{
       console.log(res)
       
       this._router.navigate(['/login'])
       },
     err=>console.log(err)
   )
  }
}
