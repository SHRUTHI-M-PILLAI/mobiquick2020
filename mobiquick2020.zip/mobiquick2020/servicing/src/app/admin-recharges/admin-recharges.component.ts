import { Component, OnInit } from '@angular/core';
import {RechargesModel} from '../recharges/recharges.model';
import {RechargesService} from '../recharges.service';
import {Router} from '@angular/router';
import {HttpResponse} from '@angular/common/http';
@Component({ 
  selector: 'app-admin-recharges',
  templateUrl: './admin-recharges.component.html',
  styleUrls: ['./admin-recharges.component.css']
})
export class AdminRechargesComponent implements OnInit {
 recharges: RechargesModel[];
  constructor(private rechargesService:RechargesService,private router:Router) { }


  update(recharge){
    this.rechargesService.setter(recharge);
     console.log('function called')
     this.router.navigate(['/update'])
   }
 
   delete(recharge){
     this.rechargesService.delete(recharge)
     location.reload();
     
   } 

  ngOnInit(): void {
    this.rechargesService.getRecharges()
    .subscribe((data)=>{
      this.recharges=JSON.parse(JSON.stringify(data));
    },
    (err)=>{
      if(err instanceof HttpResponse){
        if(err.status==500){this.router.navigate(['/adminrecharge'])}
       }
    }
    )
  }
}

