import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {RechargesModel} from './recharges/recharges.model';

@Injectable({
  providedIn: 'root'
})
export class RechargesService {
   private recharge:RechargesModel;


  constructor(private http:HttpClient) { }
  getRecharges(){
    return this.http.get("http://localhost:5000/recharge");
  }
  newRecharge(item){
    return this.http.post("http://localhost:5000/insert",{"recharge":item})
    .subscribe(data=>{console.log(data)})
  }
  updateRecharge(item)
  {
    return this.http.post("http://localhost:5000/buy",{"recharge":item})
    .subscribe(data=>{console.log(data)})

  }

  setter(recharge){
    console.log("settercalled")

    this.recharge=recharge;
    console.log(recharge);
  }
  hi(){
    return this.recharge;
  }

  delete(recharge){
    console.log("delete clicked")
    return this.http.post("http://localhost:5000/delete",{"recharge":recharge})
    .subscribe(data=>{console.log(data)})
  }
}
