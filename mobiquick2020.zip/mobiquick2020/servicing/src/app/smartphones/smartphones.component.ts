import { Component, OnInit } from '@angular/core';
import {SmartModel} from './smart.model';
import {SmartService} from '../smart.service';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';


@Component({
  selector: 'app-smartphones',
  templateUrl: './smartphones.component.html',
  styleUrls: ['./smartphones.component.css']
})
export class SmartphonesComponent implements OnInit {

  title:String = "New Arrivals";
  smartphones:[SmartModel];
  imageWidth: number=50;
  imageMargin: number=2;
  showImage: boolean = false;
   constructor(private _smart:SmartService,private _router:Router){

   }
   toggleImage(): void{
    this.showImage = !this.showImage;
  }
  
  ngOnInit(): void {
  this._smart.getSmartphones()
  .subscribe((data)=>{
    this.smartphones=JSON.parse(JSON.stringify(data));
  },
  (err)=>{
    if(err instanceof HttpErrorResponse){
      if(err.status==500){this._router.navigate(['/login'])}
     }
  }
  )
}
}





