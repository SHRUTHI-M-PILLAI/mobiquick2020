import { Component, OnInit } from '@angular/core';
import {RechargesModel} from '../recharges/recharges.model';
import {RechargesService} from '../recharges.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {
 rechargeItem = new RechargesModel(null,null,null);

  constructor(private rechargesService:RechargesService,private router:Router) { }


  

  ngOnInit(): void {
    this.rechargeItem = this.rechargesService.hi();
  }

  updateRecharge(){
    this.rechargesService.updateRecharge(this.rechargesService)
    console.log("hi for, editproduct and the corresponding product name is " + this.rechargeItem.rechargePlans);
     alert("recharged successfully")
    this.router.navigate(['/'])
  }

}
