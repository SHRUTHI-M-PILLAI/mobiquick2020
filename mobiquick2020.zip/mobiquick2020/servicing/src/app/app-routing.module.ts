import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { SmartphonesComponent } from './smartphones/smartphones.component';
import { RechargesComponent } from './recharges/recharges.component';
import { ServicingComponent } from './servicing/servicing.component';
import {BuynowComponent} from './buynow/buynow.component';
import {UserGuard} from './user.guard';
import {UpdateProductComponent} from './update-product/update-product.component';
import {HomeComponent} from './home/home.component';
import {AdminComponent} from './admin/admin.component';
import {AdminGuard} from './admin.guard';
import {AdminRechargesComponent} from './admin-recharges/admin-recharges.component';


const routes: Routes = [

  {
      path:'',
      component:HomeComponent
  },
  
  {
    path:'phones',
    component:SmartphonesComponent,
    canActivate: [UserGuard]
  },

  {
    path:'buynow',
    component:BuynowComponent,
    canActivate: [UserGuard]
  },

{
  path:'recharge',
  component:RechargesComponent,
  canActivate: [UserGuard]
},
{
  path:'buy',
  component:UpdateProductComponent,
  canActivate: [UserGuard]
 },

 {
  path:'servicing',
  component:ServicingComponent,
  canActivate: [UserGuard]
  },
  {
     path:"admin",
    component:AdminComponent,
    canActivate:[AdminGuard],
    children:[
      {
        path:'adminrecharge',
        component:AdminRechargesComponent
      }
    ]
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path: 'register',
    component:RegisterComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
