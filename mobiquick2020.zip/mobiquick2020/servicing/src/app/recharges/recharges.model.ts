export class RechargesModel{
    constructor(
    public  rechargePlans :number,
   public   rechargeValidity :number,
   public   rechargeBenifits :string){}
}


