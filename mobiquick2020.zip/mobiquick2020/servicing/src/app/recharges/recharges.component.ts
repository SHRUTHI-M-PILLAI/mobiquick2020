import { Component, OnInit } from '@angular/core'
import {RechargesModel} from './recharges.model';
import {RechargesService} from '../recharges.service';
 import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-recharges',
  templateUrl: './recharges.component.html',
  styleUrls: ['./recharges.component.css']
})
export class RechargesComponent implements OnInit {
  title:String = "3GB & 2GB/Day Pack";
  _title:String = "1.5GB/Day Packs";
  
  recharges: RechargesModel[];
  // imageWidth: number=50;
  // imageMargin: number=2;
  // showImage: boolean = false;
  
  constructor(private rechargesService:RechargesService,private _router:Router) { }
  

  
  
  
  buy(recharge){
   this.rechargesService.setter(recharge);
    console.log('function called')
    this._router.navigate(['/buy'])
  }

  // delete(recharge){
  //   this.rechargesService.delete(recharge)
  //   location.reload();
    
  // } 

 ngOnInit(): void {
   this.rechargesService.getRecharges()
   .subscribe((data)=>{
     this.recharges=JSON.parse(JSON.stringify(data));
     console.log(this.recharges)
   },
   (err)=>{
     if(err instanceof HttpErrorResponse){
       if(err.status==500){this._router.navigate(['/login'])}
      }
   }
   )
 }
}
