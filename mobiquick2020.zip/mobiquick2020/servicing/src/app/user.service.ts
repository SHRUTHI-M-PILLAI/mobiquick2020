import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Router} from '@angular/router'

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private _registerUrl = "http://localhost:5000/register";
  private _loginUrl = "http://localhost:5000/login";
  
  constructor(private http: HttpClient, private _router: Router) { }
  registerUser(user){
    return this.http.post<any>(this._registerUrl,user)
   }
   loginUser(user){
    return this.http.post<any>(this._loginUrl,user)
   }
   loggedIn(){
     return !!localStorage.getItem('token')
   }
   logoutUser(){
     localStorage.removeItem('token')
     localStorage.removeItem('user')
     this._router.navigate(['/'])
   }
   isAdmin()
   {
     var email= localStorage.getItem('user');
     if((this.loggedIn())&&(email=="mobiquick@gmail.com"))
     {
         return true;
       }
      else{
        return false;
      }
     }

   getToken(){
     return localStorage.getItem('token')
   }
 }
 