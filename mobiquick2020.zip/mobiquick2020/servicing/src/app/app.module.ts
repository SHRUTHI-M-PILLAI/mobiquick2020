import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule,HTTP_INTERCEPTORS} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import {RegisterComponent} from './register/register.component';
import { SmartphonesComponent } from './smartphones/smartphones.component';
import { RechargesComponent } from './recharges/recharges.component';
import { ServicingComponent } from './servicing/servicing.component';
import { HeaderComponent } from './header/header.component';
import {UserService} from './user.service';
import { SmartService } from './smart.service';
import {RechargesService} from './recharges.service';
import { TokenInterceptorService } from './token-interceptor.service';
import {ServicingService} from './servicing.service';
import { BuynowComponent } from './buynow/buynow.component';
import {UserGuard} from './user.guard';

import { UpdateProductComponent } from './update-product/update-product.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { AdminGuard } from './admin.guard';
import { FooterComponent } from './footer/footer.component';
import { AdminRechargesComponent } from './admin-recharges/admin-recharges.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    SmartphonesComponent,
    RechargesComponent,
    ServicingComponent,
    HeaderComponent,
    BuynowComponent,
    UpdateProductComponent,
    HomeComponent,
    AdminComponent,
    FooterComponent,
    AdminRechargesComponent
   
  
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
    
  ],
  providers: [UserService,SmartService,RechargesService,ServicingService,UserGuard,AdminGuard,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptorService,
      multi:true
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }
